<!DOCTYPE html>
<html lang="en">
	<head>
		<TITLE>Chemistry Sem</TITLE>
		<link rel="icon" type="image/png" href="../pics/iifavicon.png">
		<meta charset="UTF-8">
		<link rel="stylesheet" media="screen and (max-width:1000px)" href="../css/style'.css" type="text/css">
		<link rel="stylesheet" media="screen and (min-width:1000px)" href="../css/new2'.css">
		<script type="text/javascript" src="../css/jquery.min.js"></script>
		<script type="text/javascript">
			jQuery(window).load(function() {

				$("#nav > li > a").click(function () { // binding onclick
					if ($(this).parent().hasClass('selected')) {
						$("#nav .selected div div").slideUp(100); // hiding popups
						$("#nav .selected").removeClass("selected");
					} else {
						$("#nav .selected div div").slideUp(100); // hiding popups
						$("#nav .selected").removeClass("selected");

						if ($(this).next(".subs").length) {
							$(this).parent().addClass("selected"); // display popup
							$(this).next(".subs").children().slideDown(200);
						}
					}
				}); 

			});
		</script>
	</head>
	<body>
		<?php include('../header.php')?>
		<div class="jumbotron">
		<div class="poster">
			<img src="../pics/chemsem.jpg">
		</div>
		<?php include('../news.php')?>
			<div class="container">
			<h2>Chemistry Sem</h2>			
				<li><a href="manpro/manpro.php" title="Open contents of ManPro lab.">Manpro Lab</a><br></li>
				<li><a href="etlab/etlab.php" title="Open contents of ET lab.">ET Lab</a><br></li>
				<li><a href="chemlab/chemlab.php" title="Open contents of Chemistry lab.">Chemistry Lab</a><br></li>
				<li><a href="../maths/maths.php" title="Browse contents of Mathematics.">Mathematics</a><br></li>
				<li><a href="chem/chem.php" title="Browse contents of Chemistry.">Chemistry</a><br></li>
				<li><a href="et/et.php" title="Browse contents of ET."style="width:auto;">Electrical Technology</a><br></li>
				<li><a href="eng/English.php" title="Browse contents of English.">English</a>	</li>
			<p>
				
			</p>
			</div>
		</div>
		
		<?php include('../newsm.php')?>
		<?php include('../footer.php')?>
	</body>
</html>	