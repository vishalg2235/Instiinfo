<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Instiinfo</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="viewport" content="width=device-width initial-scale=1.0 minimum-scale=1.0">
		
		
		<link href="../../css/sidebar.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
		<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
		<link href="../../css/animate.css" rel="stylesheet" media="screen,projection" type="text/css" />
		<link href="../../css/slider.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="../../css/font-awesome.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" media="screen,projection" type="text/css" />
		<link href="../../css/menu.css" rel="stylesheet" type="text/css">
		<link href="../../engine1/style.css" rel="stylesheet" type="text/css" />
		<link href="../../css/search.css" type="text/css" rel="stylesheet" />
		<link href="../../css/footer.css" rel="stylesheet">
		<link href="list.css" rel="stylesheet">
		
		<script type="text/javascript" src="../../engine1/jquery.js"></script>
		<script type="text/javascript" src="../../js/jquery.min.js"></script>
		<script type="text/javascript" src="../../js/jquery.js"></script>
		<script type="text/javascript" src="../../js/function.js"></script>
		<script type="text/javascript" src="../../js/script.js"></script>
		<script type="text/javascript" src="../../js/jquery.slidertron-1.0.js"></script>

	</head>
	<body>
		<?php include('../../header.php')?>
		<div class="jumbotron">
			<div class="container-wrap">
				<div class="container">
					<h2>ED Lab Videos</h2>
					<center><h2>Video Lectures On Engineering Drawing</h2></center><br>
				<h3>cycloid-</h3><br>
				
				<center><iframe width="560" height="315" src="https://www.youtube.com/embed/1NImS3E2XAA" frameborder="0" allowfullscreen></iframe></center><br><br>

				<h3>Projection of lines inclined to both planes-</h3><br>
				
				<center><iframe width="560" height="315" src="https://www.youtube.com/embed/XWy9FMPVE4s" frameborder="0" allowfullscreen></iframe></center><br><br>
				<center><iframe width="560" height="315" src="https://www.youtube.com/embed/f50DndEFSxg" frameborder="0" allowfullscreen></iframe></center><br><br>
				<h3>Projection of planes-</h3><br>
				<center><iframe width="560" height="315" src="https://www.youtube.com/embed/7f_W0FftuJ0" frameborder="0" allowfullscreen></iframe></center><br><br>
				<h3>Projection of plane problems-</h3><br>
				<center><iframe width="560" height="315" src="https://www.youtube.com/embed/HnjWHta89g0" frameborder="0" allowfullscreen></iframe></center><br><br>
				<h3>Projection of solids-</h3><br>
				<center><iframe width="560" height="315" src="https://www.youtube.com/embed/OSISqnclmWA" frameborder="0" allowfullscreen></iframe></center><br><br>
				<center><iframe width="560" height="315" src="https://www.youtube.com/embed/SQntJksNGIs" frameborder="0" allowfullscreen></iframe></center><br><br>
				<h3>section of solids (basic)-</h3><br>
				<center><iframe width="560" height="315" src="https://www.youtube.com/embed/MQOF-mGDM0U" frameborder="0" allowfullscreen></iframe></center><br><br>
				<h3>section of solids pyramid-</h3><br>
				<center><iframe width="560" height="315" src="https://www.youtube.com/embed/85gk8XDDghk" frameborder="0" allowfullscreen></iframe></center><br><br>
				<h3>section of solids cone-</h3><br>
				<center><iframe width="560" height="315" src="https://www.youtube.com/embed/o4Hv_riMCqs" frameborder="0" allowfullscreen></iframe></center><br><br>
				<h3>isoometric view-</h3><br>
				<center><iframe width="560" height="315" src="https://www.youtube.com/embed/p7Tz17Af-zE" frameborder="0" allowfullscreen></iframe></center><br><br>
								
		
				</div>
			</div>
		</div>
				

		<?php include('../../socialbar.php')?>
		<?php include('../../sidebar.php')?>

		
		<?php include('../../footer.php')?>
		
	</body>
</html>