<!DOCTYPE html>
<html lang="en">
	<head>
		<TITLE>Physics Sem intiinfo IITKGP</TITLE>
		<link rel="icon" type="image/png" href="../pics/iifavicon.png">
		<meta charset="UTF-8">
		<meta name="description" content="notes question papers tutorials solutions of all the subjects of physics semester for first year iitkgp.">
		<meta name="keywords" content="iitkgp instiinfo physics, iitkgp instiinfo tutorials, iitkgp instiinfo notes, iitkgp instiinfo question papers,iitkgp instiinfo lab, iitkgp instiinfo solution">
		<link rel="stylesheet" media="screen and (max-width:1000px)" href="../css/style'.css" type="text/css">
		<link rel="stylesheet" media="screen and (min-width:1000px)" href="../css/new2'.css">
		<script type="text/javascript" src="../css/jquery.min.js"></script>
		<script type="text/javascript">
			jQuery(window).load(function() {

				$("#nav > li > a").click(function () { // binding onclick
					if ($(this).parent().hasClass('selected')) {
						$("#nav .selected div div").slideUp(100); // hiding popups
						$("#nav .selected").removeClass("selected");
					} else {
						$("#nav .selected div div").slideUp(100); // hiding popups
						$("#nav .selected").removeClass("selected");

						if ($(this).next(".subs").length) {
							$(this).parent().addClass("selected"); // display popup
							$(this).next(".subs").children().slideDown(200);
						}
					}
				}); 

			});
		</script>
	</head>
	<body>
	<?php include('../header.php')?>
	<div class="jumbotron">
		<div class="poster">
			<img src="../pics/physem.jpg">
		</div>
		<?php include('../news.php')?>
			<div class="container">
			<h2>Physics Sem</h2>				
				<li><a href="pdslab/pdslab.php" title="Open contents of PDS lab.">PDS Lab</a><br></li>
				<li><a href="phylab/phylab.php" title="Open contents of Physics lab.">Physics Lab</a><br></li>
				<li><a href="ed/edlab.php" title="Open contents of ED lab.">ED Lab</a><br></li>
				<li><a href="../maths/maths.php" title="Browse contents of Mathematics.">Mathematics</a><br></li>
				<li><a href="phy/Physics.php" title="Browse contents of Physics.">Physics</a><br></li>
				<li><a href="pds/pds.php" title="Browse contents of PDS.">PDS</a><br></li>
				<li><a href="mech/mech.php" title="Browse contents of Mechanics.">Mechanics</a>	</li>	
			<p>
				
			</p>
	</div>
		</div>
		
		<?php include('../newsm.php')?>
		<?php include('../footer.php')?>
	</body>
</html>	