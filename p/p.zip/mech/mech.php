<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Instiinfo</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="viewport" content="width=device-width initial-scale=1.0 minimum-scale=1.0">
		
		
		<link href="../../css/sidebar.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
		<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
		<link href="../../css/animate.css" rel="stylesheet" media="screen,projection" type="text/css" />
		<link href="../../css/slider.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="../../css/font-awesome.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" media="screen,projection" type="text/css" />
		<link href="../../css/menu.css" rel="stylesheet" type="text/css">
		<link href="../../engine1/style.css" rel="stylesheet" type="text/css" />
		<link href="../../css/search.css" type="text/css" rel="stylesheet" />
		<link href="../../css/footer.css" rel="stylesheet">
		<link href="list.css" rel="stylesheet">
		
		<script type="text/javascript" src="../../engine1/jquery.js"></script>
		<script type="text/javascript" src="../../js/jquery.min.js"></script>
		<script type="text/javascript" src="../../js/jquery.js"></script>
		<script type="text/javascript" src="../../js/function.js"></script>
		<script type="text/javascript" src="../../js/script.js"></script>
		<script type="text/javascript" src="../../js/jquery.slidertron-1.0.js"></script>

	</head>
	<body>
		<?php include('../../header.php')?>
		<div class="jumbotron">
			<div class="container-wrap">
				<div class="container">
					<h2>Mechanics</h2>
					
					<div class="toggle">
					<a  class="click selected" title="click here to expand" id="notes">Notes</a>
					<a  class="click" title="Click here to expand" id="tut">Tutorials</a>
					<a  class="click" title="Click here to expand" id="tutsol">Tutorial Solutions</a>
					<a  class="click"  title="Click here to expand" id="paper">Question Papers</a>
					<a  class="click" title="Click here to expand" id="books">Books</a>
					</div>
				
					<div class="content-wrap" id="notes1">
					<div class="list-container">
						<div class="list-body-container">
							<ul id="list-0" class="list-0">
								<li class="list-0-item">
									<a class="list-link">Pre Mid-sem</a><a href="paper/pre.zip" title="click here to download pre mid sem notes" class="downbut" download><i class="fa fa-download"></i></a>
								</li>
								<li class="list-0-item">
									<a class="list-link">Post Mid-sem</a><a  href="paper/post.zip" title="click here to download post mid sem notes" class="downbut" download><i class="fa fa-download"></i></a>
								</li>
								<li class="list-0-item">
									<a class="list-link" style="color: #2eb5ef;">Chapter Wise</a>
										<ul>
										<li><a class="list-link">Equivalent Force System</a><a href="notes/11.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
										<li><a class="list-link">Free Body Diagram</a><a href="notes/12.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
										<li><a class="list-link">Friction</a><a href="notes/13.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
																				
										<li><a class="list-link">Joints and Supports</a><a href="notes/14.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>	
										<li><a class="list-link">Trusses</a><a href="notes/15.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
										<li><a class="list-link">Introduction To Stress</a><a href="notes/1.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
										<li><a class="list-link">Stress and strain axial loading</a><a href="notes/2.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
										<li><a class="list-link">Torsion</a><a href="notes/3.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>	
										<li><a class="list-link">Pure Bending</a><a href="notes/4.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
										<li><a class="list-link">Beams</a><a href="notes/5.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
										<li><a class="list-link">Shearing Stress</a><a href="notes/6.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
										<li><a class="list-link">Transformation of stress</a><a href="notes/7.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
										<li><a class="list-link">Deflection in beams</a><a href="notes/8.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
										<li><a class="list-link">Principal Stress</a><a href="notes/9.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
										<li><a class="list-link">Energy Methods</a><a href="notes/10.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
									</ul>				
								</li>
							</ul>
						</div>
					</div>
					</div>
					
					<div class="content-wrap" id="tut1" style="display:none;">
					<div class="list-container">
						 <div class="list-body-container">
							<ul id="list-1" class="list-1">
								<li><a class="list-link">Tutuorial 1</a><a href="tut/1.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Tutuorial 2</a><a href="tut/2.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Tutuorial 3</a><a href="tut/3.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>	
								<li><a class="list-link">Tutuorial 4</a><a href="tut/4.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Tutuorial 5</a><a href="tut/5.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Tutuorial 6</a><a href="tut/6.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Tutuorial 7</a><a href="tut/7.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
							</ul>						
						</div>
					</div>
					</div>
					
					<div class="content-wrap" id="tutsol1" style="display:none;">
					<div class="list-container">
						 <div class="list-body-container">
							<ul id="list-2" class="list-2">
								<li><a class="list-link">Tutuorial 1</a><a href="tutsol/1.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Tutuorial 2</a><a href="tutsol/2.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Tutuorial 3</a><a href="tutsol/3.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>	
								<li><a class="list-link">Tutuorial 4</a><a href="tutsol/4.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Tutuorial 5</a><a href="tutsol/5.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Tutuorial 6</a><a href="tutsol/6.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Tutuorial 7</a><a href="tutsol/7.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
							</ul>						
						</div>
					</div>
					</div>
					
					<div class="content-wrap" id="paper1" style="display:none;">
					<div class="list-container">
						 <div class="list-body-container">
							<ul id="list-3" class="list-3">
								<li><a class="list-link">Mid Sem</a><a href="paper/mid.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">End Sem</a><a href="paper/end.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
							</ul>						
						</div>
					</div>
					</div>
					
					<div class="content-wrap" id="books1" style="display:none;">
					<div class="list-container">
						 <div class="list-body-container">
							<ul id="list-4" class="list-4">
								<li><a class="list-link">Beer nd Johnson</a><a href="book/1.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Mechanics of Material</a><a href="book/3.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Mariem Kraige</a><a href="book/4.pdf" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li>Shames (suggested book)</li>
							</ul>						
						</div>
					</div>
					</div>
				
			
				</div>
			</div>
		</div>
				

		<?php include('../../socialbar.php')?>
		<?php include('../../sidebar.php')?>

		
		<?php include('../../footer.php')?>
		
	</body>
</html>
