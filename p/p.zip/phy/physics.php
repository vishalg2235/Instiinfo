<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Instiinfo</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="viewport" content="width=device-width initial-scale=1.0 minimum-scale=1.0">
		
		
		<link href="../../css/sidebar.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
		<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
		<link href="../../css/animate.css" rel="stylesheet" media="screen,projection" type="text/css" />
		<link href="../../css/slider.css" rel="stylesheet" type="text/css" media="screen" />
		<link href="../../css/font-awesome.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" media="screen,projection" type="text/css" />
		<link href="../../css/menu.css" rel="stylesheet" type="text/css">
		<link href="../../engine1/style.css" rel="stylesheet" type="text/css" />
		<link href="../../css/search.css" type="text/css" rel="stylesheet" />
		<link href="../../css/footer.css" rel="stylesheet">
		<link href="list.css" rel="stylesheet">
		
		<script type="text/javascript" src="../../engine1/jquery.js"></script>
		<script type="text/javascript" src="../../js/jquery.min.js"></script>
		<script type="text/javascript" src="../../js/jquery.js"></script>
		<script type="text/javascript" src="../../js/function.js"></script>
		<script type="text/javascript" src="../../js/script.js"></script>
		<script type="text/javascript" src="../../js/jquery.slidertron-1.0.js"></script>

	</head>
	<body>
		<?php include('../../header.php')?>
		<div class="jumbotron">
			<div class="container-wrap">
				<div class="container">
					<h2>Physics</h2>
					
					<div class="toggle">
					<a  class="click selected" title="click here to expand" id="notes">Notes</a>
					<a  class="click"  title="Click here to expand" id="paper">Question Papers</a>
					<a  class="click" title="Click here to expand" id="books">Books</a>
					</div>
					
					<div class="content-wrap" id="notes1">
					<div class="list-container">
						<div class="list-body-container">
							<ul id="list-0" class="list-0">
								<li class="list-0-item">
									<a class="list-link">Pre Mid-sem</a><a href="paper/pre.zip" title="click here to download pre mid sem notes" class="downbut" download><i class="fa fa-download"></i></a>
								</li>
								<li class="list-0-item">
									<a class="list-link">Post Mid-sem</a><a href="paper/post.zip" title="click here to download post mid sem notes" class="downbut" download><i class="fa fa-download"></i></a>
								</li>
								<li class="list-0-item">
									<a class="list-link" style="color: #2eb5ef;">Chapter Wise</a>
									
										<ul>
												<li><a class="list-link">Oscillations</a><a href="notes/oscillations.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
												<li><a class="list-link">Waves</a><a href="notes/waves.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
												<li><a class="list-link">Interference</a><a href="notes/interference.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
												<li><a class="list-link">Fraunhofer Diffraction</a><a href="notes/diffraction.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
												<li><a class="list-link">Polarization</a><a href="notes/polarization.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
												<li><a class="list-link">Quantum Mechanics</a><a href="notes/quantum.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
												<li><a class="list-link">Resolving Power</a><a href="notes/resolving.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>								
										</ul>				
								</li>
							</ul>
						</div>
					</div>
					</div>

					
					<div class="content-wrap" id="paper1" style="display:none;">
					<div class="list-container">
						 <div class="list-body-container">
							<ul id="list-2" class="list-2">
								<li><a class="list-link">Mid Sem</a><a href="paper/mid.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">End Sem</a><a href="paper/end.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
							</ul>						
						</div>
					</div>
					</div>
					
					<div class="content-wrap" id="books1" style="display:none;">
					<div class="list-container">
						 <div class="list-body-container">
							<ul id="list-3" class="list-3">
								<li><a class="list-link">Irodov</a><a href="book/1.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Irodov Solution</a><a href="book/6.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Saraswat and Shastri</a><a href="book/2.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Jenkins nd White</a><a href="book/3.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">Physics_Waves_and_Oscillations(Somnath Bharadwaj)</a><a href="book/4.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
								<li><a class="list-link">HJ Pain</a><a href="book/5.zip" title="click here to download." class="downbut" download ><i class="fa fa-download"></i></a></li>
							</ul>
						</div>				
						</div>				
					</div>				
					
				</div>
			</div>
		</div>
				

		<?php include('../../socialbar.php')?>
		<?php include('../../sidebar.php')?>

		
		<?php include('../../footer.php')?>
		
	</body>
</html>
